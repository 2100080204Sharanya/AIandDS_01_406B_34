from django.contrib import admin
from movieapp.models import movies
from movieapp.models import movies2,reg
# Register your models here.
admin.site.register(movies)
admin.site.register(movies2)
admin.site.register(reg)